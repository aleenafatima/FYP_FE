import React from 'react'

const Footer = () => {
  return (
    <div className='flex justify-start px-5 py-2 bg-blue-800 text-white items-center bottom-0'>
        <p className='m-auto'>Copyright © 2024 - All Rights Reserved </p>
      
    </div>
  )
}

export default Footer
