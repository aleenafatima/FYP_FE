import React from 'react'
import { FaPlayCircle } from "react-icons/fa";
import { NavLink } from 'react-router-dom';

const Page2 = () => {
  return (
    <div>
        <div className='flex flex-col items-center justify-center mt-10'>
       

           

    
        </div>
    </div>
  )
}

export default Page2
